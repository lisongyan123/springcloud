package com.bank.irce.ltgj.mapper;

import com.bank.irce.ltgj.entity.dto.Custcard1ModelInvoke;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Author: XiongGaoXiang
 * @Date: 2020/7/21
 */
public interface Custcard1ModelInvokeMapper extends BaseMapper<Custcard1ModelInvoke> {
}
