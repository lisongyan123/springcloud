package com.bank.irce.ltgj.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * DEVICE_STATUS_INFO
 * @author 
 */
@Data
public class DeviceStatusInfo implements Serializable {
    private String deviceId;

    private static final long serialVersionUID = 1L;
}