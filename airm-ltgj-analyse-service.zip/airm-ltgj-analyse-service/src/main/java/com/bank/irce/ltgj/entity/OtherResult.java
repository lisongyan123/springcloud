package com.bank.irce.ltgj.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * OTHER_RESULT
 * @author 
 */
@Data
public class OtherResult implements Serializable {
    private String reserve1;

    private static final long serialVersionUID = 1L;
}