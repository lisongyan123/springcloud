package com.bank.irce.ltgj.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * AIRM_LTGJ_MODEL_LTDSJ_INFO
 * @author 
 */
@Data
public class AirmLtgjModelLtdsjInfo implements Serializable {
    private String model1;

    private String model2;

    private String model3;

    private String model4;

    private String model5;

    private String model6;

    private String model7;

    private String model8;

    private String model9;

    private String model10;

    private String model11;

    private String model12;

    private String model13;

    private String model14;

    private String model15;

    private String model16;

    private String model17;

    private String model18;

    private String model19;

    private String model20;

    private String model21;

    private String model22;

    private String model23;

    private String model24;

    private String model25;

    private String model26;

    private String model27;

    private String model28;

    private String model29;

    private String model30;

    private String reserve1;

    private String reserve2;

    private String reserve3;

    private static final long serialVersionUID = 1L;
}