package com.bank.irce.ltgj.mapper;

import com.bank.irce.ltgj.entity.AirmLtgjMasterAuditCredit;

public interface AirmLtgjMasterAduitCreditDao {
    int insert(AirmLtgjMasterAuditCredit record);

    int insertSelective(AirmLtgjMasterAuditCredit record);
}