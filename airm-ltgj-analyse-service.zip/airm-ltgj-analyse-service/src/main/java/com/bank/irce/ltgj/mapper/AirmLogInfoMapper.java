package com.bank.irce.ltgj.mapper;

import com.bank.irce.ltgj.entity.dto.AirmLogInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Author: XiongGaoXiang
 * @Date: 2020/7/23
 */
public interface AirmLogInfoMapper extends BaseMapper<AirmLogInfo> {

}
