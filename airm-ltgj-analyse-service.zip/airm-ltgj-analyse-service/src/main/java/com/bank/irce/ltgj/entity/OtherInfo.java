package com.bank.irce.ltgj.entity;

import java.io.Serializable;
import lombok.Data;

/**
 * OTHER_INFO
 * @author 
 */
@Data
public class OtherInfo implements Serializable {
    private String reserve1;

    private static final long serialVersionUID = 1L;
}